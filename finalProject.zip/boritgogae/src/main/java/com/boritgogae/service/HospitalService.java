package com.boritgogae.service;

public interface HospitalService {
	
}
