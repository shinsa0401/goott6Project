package com.boritgogae.service;

public interface MemberService {

}
