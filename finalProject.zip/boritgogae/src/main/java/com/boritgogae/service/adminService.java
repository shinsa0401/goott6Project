package com.boritgogae.service;

public interface adminService {

}
