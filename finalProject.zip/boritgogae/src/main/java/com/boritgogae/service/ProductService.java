package com.boritgogae.service;

public interface ProductService {
	
}
