package com.boritgogae.service;

public class MemberServiceImpl implements MemberService {

}
