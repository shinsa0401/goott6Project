package com.boritgogae.domain;

public class LoginDTO {

}
