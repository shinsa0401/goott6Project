package com.boritgogae.domain;

public class MemberVo {

}
