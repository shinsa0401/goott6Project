package com.boritgogae.persistence;

public interface OrderDAO {

}
