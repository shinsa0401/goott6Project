package com.boritgogae.persistence;

public class MemberDAOImpl implements MemberDAO {

}
