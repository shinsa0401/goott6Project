package com.boritgogae.persistence;

public interface adminDAO {

}
