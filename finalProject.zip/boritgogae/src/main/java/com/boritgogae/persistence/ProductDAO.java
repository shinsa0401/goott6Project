package com.boritgogae.persistence;

public interface ProductDAO {

}
