package com.boritgogae.persistence;

public interface MemberDAO {

}
