package com.boritgogae.controller;

public class adminController {

}
