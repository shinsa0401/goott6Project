package com.boritgogae.controller;

public class HospitalController {

}
