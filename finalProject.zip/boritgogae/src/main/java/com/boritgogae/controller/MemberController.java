package com.boritgogae.controller;

public class MemberController {

}
